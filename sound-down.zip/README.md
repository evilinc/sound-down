# 音频大盗
下载你在浏览器中能听到的任何声音

![down](https://img.shields.io/badge/download-1K-brightgreen.svg)
![browser](https://img.shields.io/badge/browser-chrome-brightgreen.svg)
![auther](https://img.shields.io/badge/auther-44886-brightgreen.svg)

是的，不区分网站，只要你在浏览器中播放了声音，本扩展就能拿下它的真实地址，让你下载。

举个小例子吧！这个网站（乱找的一个），进入播放声音的页面后，先试听一下（有些网站也不用试听，为了保险，就叫大家都试听了）。

![示例图片](http://cdn.44886.com/tools/image/1521253677506_4a47a0db6e60853dedfcfdf08a5ca249.png)

左边会多出来一个小按钮，就是本工具的logo

![示例图片](http://cdn.44886.com/tools/image/1521253716704_fb5c81ed3a220004b71069645f112867.png)

点击它吧，你可以看到当前页面中正在播放的音乐的真实地址。

![示例图片](http://cdn.44886.com/tools/image/1521253749608_10fb15c77258a991b0028080a64fb42d.png)

可以一键下载。

# 下载
如果你仅仅只想使用本工具，请 [点击下载](https://raw.githubusercontent.com/44886/sound-down/master/release/sound-down.crx)。

下载后，将文件拖到你浏览器的 [`扩展页面`](chrome://extensions) 页面。

然后，去音乐网站听音乐吧！不用再充VIP了！

# 共享

源代码已经贡献出来啦，大家可以一起来修改它。

# 遗留问题

部分网站的音频文件,Content-Type是在线播放的，暂时只能`右键`->`另存为`来下载，等我修复吧！